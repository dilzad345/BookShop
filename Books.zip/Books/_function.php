<?php

function getDBconnection () {

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "book";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn){

	die("my db connection error" . mysqli_connect_error());
}
	return $conn ;
}

?>

