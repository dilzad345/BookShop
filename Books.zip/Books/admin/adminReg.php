<?php

include ("function.php");
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Taxi</title>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700;900&family=Ubuntu:wght@300;400;500;700&display=swap"
    rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

  <!-- Custom Style -->
  <link rel="stylesheet" href="css/styles.css">

  <style>
      #message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}
  </style>
</head>

<body>

  <section id="title">

    <div class="container-fluid">

      <!-- Nav Bar -->
      <nav class="navbar navbar-expand-lg navbar-dark">
        <a href="dashboard.php" class="navbar-brand">City Taxi</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
          aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a href="dashboard.php" class="nav-link">Dashboard</a>
            </li>
           
            <!-- <li class="nav-item">
              <a href="#cta" class="nav-link">Download</a>
            </li> -->
          </ul>
        </div>
      </nav>

      <?php

if (isset($_POST['btnRegisterDr'])) {

        $name = $_POST['name'];
        $mail = $_POST['mail'];
        $number = $_POST['number'];
        $nic = $_POST['nic'];
        $password = $_POST['password'];
        


            $conn = getDBconnection();

            $sql = "INSERT INTO adminReg (name,mail,number,nic,password) VALUES ('$name','$mail','$number','$nic','$password')";

            if (mysqli_query($conn, $sql)) {
                echo "<script>alert('Insert Success')</script>";
            }
            else {
                echo "<script>alert('Somethink Went Wrong')</script>";
            }


        }

 ?>

      <!-- login -->
      <form action="adminReg.php" method="post"> 
          <div>
              <h1 style="text-align: center;">Admin Signin</h1>
          </div>

          <div class="mb-3">
            <label for="Number" class="form-label">name:</label>
            <input name="name" type="Text" class="form-control" id="exampleInputPassword1" required>
          </div>

        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Email address:</label>
          <input name="mail" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
          
        </div>
        <div class="mb-3">
            <label for="Number" class="form-label">Phone No:</label>
            <input name="number" type="Number" class="form-control" id="exampleInputPassword1" required>
          </div>
          <div class="mb-3">
            <label for="Number" class="form-label">NIC No:</label>
            <input name="nic" type="text" class="form-control" id="exampleInputPassword1" required>
          </div>
          
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Password:</label>
          <input name="password" type="password" class="form-control" id="psw" name="psw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
        </div>
        
        <button type="submit" class="btn btn-secondary" name="btnRegisterDr">Submit</button>
      </form>

      <div id="message">
        <h3>Password must contain the following:</h3>
        <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
        <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
        <p id="number" class="invalid">A <b>number</b></p>
        <p id="length" class="invalid">Minimum <b>8 characters</b></p>
      </div>

     
  </section>

  <!-- Features -->

  <section id="">

    

  </section>

  <!-- Press -->

 

  <!-- Pricing -->

  

  <!-- Footer -->

  <footer id="footer">

    <i class="social-icon fab fa-facebook-f"></i>
    <i class="social-icon fab fa-twitter"></i>
    <i class="social-icon fab fa-instagram"></i>
    <i class="social-icon fas fa-envelope"></i>

    <p>© Copyright 2021 E-Texi Pvt Ltd.</p>  

  </footer>

  <script>
    var myInput = document.getElementById("psw");
    var letter = document.getElementById("letter");
    var capital = document.getElementById("capital");
    var number = document.getElementById("number");
    var length = document.getElementById("length");
    
    // When the user clicks on the password field, show the message box
    myInput.onfocus = function() {
      document.getElementById("message").style.display = "block";
    }
    
    // When the user clicks outside of the password field, hide the message box
    myInput.onblur = function() {
      document.getElementById("message").style.display = "none";
    }
    
    // When the user starts to type something inside the password field
    myInput.onkeyup = function() {
      // Validate lowercase letters
      var lowerCaseLetters = /[a-z]/g;
      if(myInput.value.match(lowerCaseLetters)) {  
        letter.classList.remove("invalid");
        letter.classList.add("valid");
      } else {
        letter.classList.remove("valid");
        letter.classList.add("invalid");
      }
      
      // Validate capital letters
      var upperCaseLetters = /[A-Z]/g;
      if(myInput.value.match(upperCaseLetters)) {  
        capital.classList.remove("invalid");
        capital.classList.add("valid");
      } else {
        capital.classList.remove("valid");
        capital.classList.add("invalid");
      }
    
      // Validate numbers
      var numbers = /[0-9]/g;
      if(myInput.value.match(numbers)) {  
        number.classList.remove("invalid");
        number.classList.add("valid");
      } else {
        number.classList.remove("valid");
        number.classList.add("invalid");
      }
      
      // Validate length
      if(myInput.value.length >= 8) {
        length.classList.remove("invalid");
        length.classList.add("valid");
      } else {
        length.classList.remove("valid");
        length.classList.add("invalid");
      }
    }
    </script>
    

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
    integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
    integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous">
  </script>
</body>

</html>