
<!DOCTYPE html>
<html>
<head>
<style>



h1 {
  text-align: center;
}
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: gray;
  color: white;
}
#log {
  float:right;
}


</style>
</head>
<body>
<button href="admin.php" id="log">Logout</button>
<h1>Book Ordered Details</h1>

<table id="customers">
  <tr>
    <th>Book Name</th>
    <th>Book Number</th>
    <th>Book Author</th>
    <th>Book Price</th>
    <th>Order</th>
  </tr>
  <tr>
    <td> In Search of Lost Time</td>
    <td>07585</td>
    <td>Mrce</td>
    <td>7500</td>
    <td>
         <button>Order</button>
        <button>Delete</button>
        
        </td>
  </tr>
  <tr>
    <td>Ulysses</td>
    <td>89658</td>
    <td>Bey</td>
    <td>2300</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>Don Quixote </td>
    <td>78526</td>
    <td>ledino</td>
    <td>1800</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>One Hundred Years of Solitude</td>
    <td>25635</td>
    <td>cantrad</td>
    <td>1200</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>The Great Gatsby</td>
    <td>12050</td>
    <td>pelonks</td>
    <td>3000</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>Moby Dick by Herman Melville</td>
    <td>96325</td>
    <td>mark</td>
    <td>4200</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>War and Peace </td>
    <td>41528</td>
    <td>jobs</td>
    <td>1260</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>Magazzini Alimentari Riuniti</td>
    <td>96325</td>
    <td>peyal</td>
    <td>7400</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>North/South</td>
    <td>74125</td>
    <td>vilad</td>
    <td>2300</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
  <tr>
    <td>Paris spécialités</td>
    <td>85285</td>
    <td>minoth</td>
    <td>4200</td>
    <td><button>Order</button>
    <button >Delete</button></td>
  </tr>
</table>



</body>
</html>


