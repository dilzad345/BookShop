

 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <title>Taxi</title>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700;900&family=Ubuntu:wght@300;400;500;700&display=swap"
    rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

  <!-- Custom Style -->
  <link rel="stylesheet" href="css/styles.css">
</head>
<style>
    #customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FDFEFE;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #979A9A;
  color: white;
}
</style>
<body>



 <div style="margin-left:15%">



<div class="container" align="center">
  <h2>Book Edit</h2>




<?php
// insert data into the database 
include('function.php');

?>


<?php
//getting news form the database tbl_news
$conn =  getDBconnection ();




//updating


if(isset($_POST['update_btn'])){
$id = $_POST['id'];
$name = $_POST['name'];
$number = $_POST['number'];
$author = $_POST['author'];
$price = $_POST['price'];

$query = "UPDATE bookadd SET name = '$name' , number = '$number', author = '$author', price = '$price' WHERE id = $id ";
//$query = "UPDATE tbl_news SET news_description = '$new_desc', desc2 = '$value', desc3 = ''  WHERE id = $id ";
//echo $query;
if (mysqli_query($conn, $query)) {
  echo "<script>alert('Record updated successfully')</script>";
} else {
    echo "<script>alert('Error Update')</script>" . mysqli_error($conn);
}

}








$id = $_GET['id'];

 $sql = "SELECT * FROM bookadd WHERE id = $id";


  $result = mysqli_query($conn , $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {
?>


<div class="alert alert-danger alert-dismissible">
  
    <td>
                <form action="bookingEdit.php?id=<?php echo $row['id'] ?>" method="post">
                  <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                  <input name="name" value="<?php echo $row['name']?>" />
                  <input name="number" value="<?php echo $row['number']?>" />
                  <input name="author" value="<?php echo $row['author']?>" />
                  <input name="price" value="<?php echo $row['price']?>" />
                
                  <button type="submit" name="update_btn" class="btn btn-danger"> Update </button>

                 
                </form>
            </td>
  </div>

<?php
                                    

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }


?>

  





   

  




  




</div>
</div>
</body>
</html>
