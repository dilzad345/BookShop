
<?php
include('_function.php');
?>





<!DOCTYPE html>
<html>
<head>
	<title>Private Motor Insurance Questionnarie</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<style>
	
	.btnlog {
    float: right;
  border: none;
  color: white;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  background-color: #2196F3;
  margin-top: 20px;
  margin-right: 30px;


</style>
<body>

	


	<div class="hero">

		<!-- <a href="logout.php"> <button class="btnlog">Logout</button></a> -->
		<div class="form-box" style="background-color: #e4e4ee">
			<div class="button-box">
				<div id="btn"></div>
				<button type="button" class="toggle-btn" onclick="login()">Log In</button>
				<button type="button" class="toggle-btn" onclick="register()">Register</button>
			</div>


			<form id="login" class="input-group1" action="allBooks.php" method="post">
				<input type="text"  name="First_Name" class="input-fiel" placeholder="Enter Your First Name" required="">
				<input type="password"  name="Password" class="input-fiel" placeholder="Enter Your Password" required="">
				<button type="submit" class="submit-btn" name="login">Login</button>



				
			</form>

			<form id="register" class="input-group" action="allbooks.php" method="post">
				<input type="text"  name="First_Name" class="input-fiel" placeholder="Enter Your First Name" required="">
				<input type="text"  name="Second_Name" class="input-fiel" placeholder="Enter Your Last Name" required="">
				
				<input type="text"  name="Job_Title" class="input-fiel" placeholder="Enter Your Email" required="">
				<input type="text"  name="Manager" class="input-fiel" placeholder="Enter Your Phone Number" required="">
				<input type="password"  name="Password" id="psw" class="input-fiel" placeholder="Enter Your Password" required="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}">
				<input type="password"  name="cpassword" id="psw1" class="input-fiel" placeholder="Confirm Password" required="">
				
				<button type="submit" class="submit-btn" name="register" onclick="return Validate()">Register</button>

				
			</form>



		</div>
	</div>

	<div id="message">
  <h3>Password must contain the following:</h3>
  <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
  <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
  <p id="number" class="invalid">A <b>number</b></p>
  <p id="length" class="invalid">Minimum <b>8 characters</b></p>
</div>

	<script>
		
		var x = document.getElementById("login");
		var y = document.getElementById("register");
		var z = document.getElementById("btn");

		function register () {
			x.style.left = "-400px";
			y.style.left = "50px";
			z.style.left = "110px";
		}

		function login () {
			x.style.left = "50px";
			y.style.left = "450px";
			z.style.left = "0px";
		}


	</script>

<script>
var myInput = document.getElementById("psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>

<script>
    function Validate() {
        var password = document.getElementById("psw").value;
        var confirmPassword = document.getElementById("psw1").value;
        if (password != confirmPassword) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
    }
</script>


</body>
</html>