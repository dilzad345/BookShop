

<?php


// insert data into the database 
include('_function.php');



if (isset($_POST['submit'])) {

                            
                            $date1 = $_POST['date1'];
                            $ClinicNumber = $_POST['ClinicNumber'];
                            $RegisterNumber = $_POST['RegisterNumber'];
                            $Gender = $_POST['Gender'];
                            $FirstName = $_POST['FirstName'];
                            $LastName = $_POST['LastName'];
                            $Age = $_POST['Age'];
                            $PhoneNumber = $_POST['PhoneNumber'];
                            $NICNumber = $_POST['NICNumber'];
                            
                            

                            

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO clinicdetails (date1,ClinicNumber,RegisterNumber,Gender,FirstName,LastName,Age,PhoneNumber,NICNumber) VALUES ('$date1','$ClinicNumber','$RegisterNumber','$Gender','$FirstName','$LastName','$Age','$PhoneNumber','$NICNumber')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Successfully Insert Record')</script>";
                                }
                                else {
                                  echo ("error: " . mysqli_error($conn));
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }

?>

<!DOCTYPE html>
<html>
<head>
	<title>BOOK ORDER FORM</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<style>
  table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  height: 50%;
  
}

tr:nth-child(even) {
  background-color: #dddddd;
}


.btnlog {
    float: right;
  border: none;
  color: white;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  background-color: #2196F3;
}
  h1 {
  text-align: center;
}
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: gray;
  color: white;
}
#search {
    float:right;
    margin-bottom:10px;
    padding:10px;
}
#log {
  float:right;
}
</style>

<body>
<button href="admin.php" id="log">Logout</button>
   
	<div class="wrapper">																		
		<div class="title">ADD NEW BOOK</div>

		<div class="form">
			<div class="input_field">
				
				
			</div>

      
			
			
			<div class="input_field">
				<label>Book Name</label>
				<input type="text" class="input" name="ClinicNumber" id="fname" placeholder="" required="">
			</div>
			
			<div class="input_field">
				<label>Book Number</label>
				<input type="text" class="input" name="RegisterNumber" required>
			</div>
			
			<div class="input_field">
				<label>Book Author</label>
				<input type="text" class="input" name="FirstName" required>
			</div>
			<div class="input_field">
				<label>Book Price</label>
				<input type="text" class="input" name="LastName" required>
			</div>
			
		

		<br>

			<div class="input_field">
				
			
				<input type="submit" class="btn" name="submit" value="Add Book">
			</div>

			</div>
	</div>
</form>

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


<h1>All Book List</h1>   
 <input id="search" type="text" placeholder="Search Your Books......">

<table id="customers">
  <tr>
    <th>Book Name</th>
    <th>Book Number</th>
    <th>Book Author</th>
    <th>Book Price (RS)</th>
    <th>Book Delete</th>
  </tr>
  <tr>
    <td> In Search of Lost Time</td>
    <td>07585</td>
    <td>Mrce</td>
    <td>7500</td>
    <td>
        <button id=btnDelete>Delete</button>
        
        </td>
  </tr>
  <tr>
    <td>Ulysses</td>
    <td>89658</td>
    <td>Bey</td>
    <td>2300</td>
    <td><button>Delete</button>
    </td>
  </tr>
  <tr>
    <td>Don Quixote </td>
    <td>78526</td>
    <td>ledino</td>
    <td>1800</td>
    <td><button>Delete</button>
    </td>
  </tr>
  <tr>
    <td>One Hundred Years of Solitude</td>
    <td>25635</td>
    <td>cantrad</td>
    <td>1200</td>
    <td><button>Delete</button>
   </td>
  </tr>
  <tr>
    <td>The Great Gatsby</td>
    <td>12050</td>
    <td>pelonks</td>
    <td>3000</td>
    <td><button>Delete</button>
    </td>
  </tr>
  <tr>
    <td>Moby Dick by Herman Melville</td>
    <td>96325</td>
    <td>mark</td>
    <td>4200</td>
    <td><button>Delete</button>
   </td>
  </tr>
  <tr>
    <td>War and Peace </td>
    <td>41528</td>
    <td>jobs</td>
    <td>1260</td>
    <td><button>Delete</button>
    </td>
  </tr>
  <tr>
    <td>Magazzini Alimentari Riuniti</td>
    <td>96325</td>
    <td>peyal</td>
    <td>7400</td>
    <td><button>Delete</button>
    </td>
  </tr>
  <tr>
    <td>North/South</td>
    <td>74125</td>
    <td>vilad</td>
    <td>2300</td>
    <td><button>Delete</button>
    </td>
  </tr>
  <tr>
    <td>Paris spécialités</td>
    <td>85285</td>
    <td>minoth</td>
    <td>4200</td>
    <td><button>Delete</button>
   </td>
  </tr>
</table>

<br><br>


<?php 
    
    include("footer.php");
    
    ?>


</body>
</html>