<?php
include('header.php');
?>

<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<style>
body, html {
  height: 100%;
  margin: 0;
}

.bbtn {
  position: absolute;
  top: 50%;
  left: 28%;
  
}

.button1 {background-color: green;} /* Blue */
.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7;} /* Gray */ 
.button5 {background-color: #555555;} /* Black */

.abc {
  position: absolute;
  top: 20%;
  left: 40%;
  transform:
  
}

.bg {
  /* The image used */
  background-image: url("bk.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}


</style>
</head>
<body>

<h1 class="abc">All Book Category</h1>   

<div class="bbtn">
<a href="adventure.php"><button style="width:100px; height:50px;" class="button button1">Adventure</button></a> &nbsp; &nbsp; &nbsp; &nbsp;
<a href="classic.php"><button style="width:100px; height:50px;" class="button button2">Classics</button></a> &nbsp; &nbsp; &nbsp; &nbsp;
<a href="fantasy.php"><button style="width:100px; height:50px;" class="button button3">Fantasy</button></a> &nbsp; &nbsp; &nbsp; &nbsp;
<a href="horror.php"><button style="width:100px; height:50px;" class="button button4">Horror</button></a> &nbsp; &nbsp; &nbsp; &nbsp;
<a href="historical.php"><button style="width:100px; height:50px;" class="button button5">Historical</button></a> &nbsp; &nbsp; &nbsp; &nbsp;
</div>
 

 <div class="bg"></div>

</body>
</html>


