<?php 

include('header.php');

 ?>

<?php


// insert data into the database 
include('_function.php');



if (isset($_POST['submit'])) {

                            
                            $name = $_POST['name'];
                            $number = $_POST['number'];
                            $author	 = $_POST['author'];
                            $price = $_POST['price'];
                            
                            

                            

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO adventure (name,number,author,price) VALUES ('$name','$number','$author','$price')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Successfully Order Your Book')</script>";
                                }
                                else {
                                  echo ("error: " . mysqli_error($conn));
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }

?>

<!DOCTYPE html>
<html>
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
<body>

<h3 style="text-align:center;">Order Your Book</h3>

<div>
  <form action="list.php" method="post">

    <label for="fname">Book Name</label>
    <input type="text" id="fname" name="name" placeholder="Book name..">

    <label for="fname">Book Number</label>
    <input type="text" id="fname" name="number" placeholder="Book Number..">

    <label for="lname">Author Name</label>
    <input type="text" id="lname" name="author" placeholder="Author name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="price" placeholder="Book Price..">

    
  
    <input type="submit" value="Submit" name="submit">
  </form>
</div>

</body>
</html>






