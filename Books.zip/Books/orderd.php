<?php
include('header.php');
?>

<?php 

include('_function.php');

 ?>

<!DOCTYPE html>
<html>
<head>
<style>



h1 {
  text-align: center;
}
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid green;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FEF9A7;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: gray;
  color: white;
}


</style>
</head>
<body>

<h1>Book Ordered Details</h1>

<table id="customers">
  <tr>
    <th>Book Name</th>
    <th>Book Number</th>
    <th>Book Author</th>
    <th>Book Price</th>
    <th>Order Delete</th>
  </tr>

  <?php 

$conn =  getDBconnection ();
$sql = "SELECT * FROM adventure";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>

<tr>
    <td style="color:Black"><?php echo $row['name'] ?></td>
    <td style="color:Black"><?php echo $row['number'] ?></td>
    <td style="color:Black"><?php echo $row['author'] ?></td>
    <td style="color:Black"><?php echo $row['price'] ?></td>
    
    
    <td>
                <form action="order.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="" class="btn btn-success">Delete</button>
                  <a href="orderd.php?id=<?php echo $row['id'] ?>" class="btn btn-danger" >Edit</a>
                   </form>
            </td>
</tr>

<?php                            

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }

?>

  
  
</table>



</body>
</html>


