<!DOCTYPE html>
<html>
<head>
  <title>Private Motor Insurance Questionnarie</title>
</head>
<style>
  
  nav {
    background: #2F8F9D;
    height: 80px;
    width: 100%;
}

label.logo {
  color: white;
  font-size: 35px;
  line-height: 80px;
  padding: 0 100px;
  font-weight: bold;
} 

nav ul {
  float: right;
  margin-right: 20px;
}

nav ul li {
  display: inline-block;
  line-height: 50px;
  margin: 0 5px;
}

nav ul li a {
  color: white;
  font-size: 17px;
  padding: 7px 13px;
  border-radius: 3px;
  text-transform: uppercase;
  text-decoration:none;
} 

a:hover {
  background:#1b9bff;
  transition: .5s; 
}

.logo {
  width: 70px;

  float: left;
  height: auto;
  margin-left: 30px;
  margin-top: 4px;
}
</style>

<body>

<nav>
  <a  href="index.php"><img src="logonew.jpg" class="logo"></a>
  <ul>
    <li><a class="active" href="#" >Home</li></a>
    <li><a class="active" href="catgery.php" >category</li></a>
    <li><a class="active" href="list.php" >Order</li></a>
    <li><a class="active" href="orderd.php" >Order List</li></a>
    <li><a class="active" href="home.php" >FeedBack</li></a>
    <li><a class="active" href="index.php" >Log Out</li></a>
  </ul>
  
</nav>

</body>
</html>