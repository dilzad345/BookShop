

<?php


// insert data into the database 
include('_function.php');



if (isset($_POST['submit'])) {

                            
                            $ClinicNumber = $_POST['ClinicNumber'];
                            $RegisterNumber = $_POST['RegisterNumber'];
                           
                            $FirstName = $_POST['FirstName'];
                            $LastName = $_POST['LastName'];
                            
                            $PhoneNumber = $_POST['PhoneNumber'];
                            $review = $_POST['review'];
                           
                            
                            

                            

                          $conn =  getDBconnection ();

                    $sql = "INSERT INTO feedback (ClinicNumber,RegisterNumber,FirstName,LastName,PhoneNumber,review) VALUES ('$ClinicNumber','$RegisterNumber','$FirstName','$LastName','$PhoneNumber','$review')";

                    if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Successfully Insert Record')</script>";
                                }
                                else {
                                  echo ("error: " . mysqli_error($conn));
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }
                          }

?>

<!DOCTYPE html>
<html>
<head>
	<title>BOOK ORDER FORM</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<style>
  /* Inherit */
  span {
  color: #371B58;
  border: 1px solid black;
}

.extra span {
  color: inherit;
}

/* Abstract */

/* This means nothing... */
.animate {
  animation: my-animation 0.2s;
}

/* ...if not for this, which could be anywhere or nowhere */
@keyframes my-animation {
  to { color: red; }
}


/* Polymorephism */
background:#fff; /* The background is white */
background:url(img.png); /* The background is an image */
background:#fff url(img.png); /* The background is white with an image */
background:url(img.png) no-repeat; /* The background is a non-repeating image */
/* Etc... */


  table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  height: 50%;
  
}

tr:nth-child(even) {
  background-color: #dddddd;
}

.title {
  color:#371B58;
}


.btnlog {
    float: right;
  border: none;
  color: #371B58;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
  background-color: #371B58;
</style>

<body>
  <?php 

include('header.php');

 ?>
   
	<div class="wrapper">																		
		<div class="title">FEEDBACK</div>

		<div class="form">
			<div class="input_field">
				
				
			</div>

      
			
			<form id="login" class="" action="home.php" method="post">
			<div class="input_field">
				<label>Book Number</label>
				<input type="text" class="input" name="ClinicNumber" id="fname" placeholder="" required="">
			</div>
			
			<div class="input_field">
				<label>Register Number</label>
				<input type="text" class="input" name="RegisterNumber">
			</div>
			
			<div class="input_field">
				<label>Book Name</label>
				<input type="text" class="input" name="FirstName">
			</div>
			<div class="input_field">
				<label>Book Author</label>
				<input type="text" class="input" name="LastName">
			</div>
			
			<div class="input_field">
				<label>Phone Number</label>
				<input type="text" class="input" name="PhoneNumber">
			</div>

			<div class="input_field">
				<label>Feedback</label>
				<textarea id="w3review" name="review" rows="4" cols="70"></textarea>
			</div>
      
      
      <br>

			<div class="input_field">
				
			
				<input type="submit" class="btn" name="submit" value="Feedback">
			</div>

			</div>
	</div>
</form>

/* Encapsulation */
<script>
class LitComponent extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({mode: 'open'})
  }

  connectedCallback() {
    let style = document.createElement('style');
    style.innerHTML = `
    p {
      font-size: 80px;
    }
    `
    this.shadowRoot.appendChild(style);
    render(this.createView(), this);
  }

  createView() {
    return html`
      <p> styled </p>
    `;
  }
}
customElements.define("lit-component", LitComponent);

</script>


<?php 
    
    include("footer.php");
    
    ?>


</body>
</html>