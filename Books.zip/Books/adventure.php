<?php
include('header.php');
?>

<?php
include('_function.php');


   


                    if (isset($_POST['adventure'])) {

                            $name = $_POST['name'];
                            $number = $_POST['number'];
                            $author = $_POST['author'];
                            $price = $_POST['price'];
                            
                            
                            


                                $conn = getDBconnection();

                                $sql = "INSERT INTO adventure (name,number,author,price) VALUES ('$name','$number','$author','$price')";

                                if (mysqli_query($conn, $sql)) {
                                    echo "<script>alert('Successfully Created Account')</script>";
                                }
                                else {
                                    echo "<script>alert('Somethink Went Wrong')</script>";
                                }


                            }

                        ?>


<!DOCTYPE html>
<html>
<head>
<style>



h1 {
  text-align: center;
}
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid green;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FEF9A7;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: gray;
  color: white;
}
#search {
    float:right;
    margin-bottom:10px;
    padding:10px;
}

</style>
</head>
<body>

<h1>Adventure Book List</h1>   
 <!-- <input id="search" type="text" placeholder="Search Your Books......"> -->
<div>
 <form  method="post"> 
  <input id="search" type="text" name="name" placeholder="Enter Your Book Name...." />
  <input style="margin-left:95%;" type="submit" name="btnSearch" value="Search" />
</form>
</div>


<br><Br>


 <form id="adventure" class="input-group" action="adventure.php" method="post">
<table id="customers">
  <tr>
    <th>Book Name</th>
    <th>Book Number</th>
    <th>Book Author</th>
    <th>Book Price (RS)</th>
    
  </tr>

  <?php
$conn =  getDBconnection ();


if(isset($_POST['btnSearch']))
{
  $name = $_POST['name'];
  $sqlpname = "SELECT * FROM adventure WHERE name LIKE '%$name%'";
$result2 = mysqli_query($conn , $sqlpname);
  if (mysqli_num_rows($result2) > 0) {
                                    foreach ($result2 as $row) {
?>
Book Name : <?php echo $row['name'] ?> <br>
Book Number : <?php echo $row['number'] ?> <br>
Author : <?php echo $row['author'] ?> <br>
Price : <?php echo $row['price'] ?> 


<?php

                                    }}

}

?>

  <?php 

$conn =  getDBconnection ();
$sql = "SELECT * FROM bookadd";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>

  <tr>
    <td><?php echo $row['name'] ?></td>
    <td><?php echo $row['number'] ?></td>
    <td><?php echo $row['author'] ?></td>
    <td><?php echo $row['price'] ?></td>
  

</tr>
<?php                            

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }

?>
  
</table>  

</body>
</html>


